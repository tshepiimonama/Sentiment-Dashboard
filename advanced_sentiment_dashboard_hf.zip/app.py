import streamlit as st
import pandas as pd
from components.sentiment_analysis import analyze_sentiments_vader, analyze_sentiments_hf
from components.visuals import display_charts, export_data
from components.utils import parse_text_input

st.set_page_config(
    page_title="Sentiment Explorer 💬",
    page_icon="💬",
    layout="wide"
)

st.markdown(
    "<h1 style='color:#6C63FF;text-align:center;'>Sentiment Explorer Dashboard</h1>"
    "<p style='text-align:center;'>Analyze emotional tone in text data such as reviews, feedback, or social media posts.</p>",
    unsafe_allow_html=True
)

st.sidebar.header("📥 Data Input")
input_type = st.sidebar.radio("Choose how to input text data:", ["Text Box", "Upload File"])

model_choice = st.sidebar.selectbox("Choose Sentiment Model", ["VADER (local, free)", "Hugging Face API (requires token)"])

text_data = []

if input_type == "Text Box":
    st.subheader("✍️ Enter or Paste Text")
    st.info("Enter one text entry per line (e.g., customer reviews, tweets).")
    user_input = st.text_area("Your text entries go here:", height=200, placeholder="Type or paste text...")
    if user_input:
        text_data = parse_text_input(user_input)

elif input_type == "Upload File":
    uploaded_file = st.sidebar.file_uploader("Upload a CSV or TXT file", type=["csv", "txt"])
    if uploaded_file:
        if uploaded_file.name.endswith(".csv"):
            df = pd.read_csv(uploaded_file)
            st.subheader("📊 Preview Uploaded Data")
            st.write(df.head())
            text_column = st.sidebar.selectbox("Select column with text:", df.columns)
            text_data = df[text_column].dropna().tolist()
        else:
            content = uploaded_file.read().decode("utf-8")
            text_data = content.splitlines()

if text_data:
    st.markdown("### 🧠 Sentiment Analysis Results")
    if model_choice == "VADER (local, free)":
        results_df = analyze_sentiments_vader(text_data)
    else:
        results_df = analyze_sentiments_hf(text_data)

    with st.expander("📋 View Annotated Table"):
        st.dataframe(results_df)

    col1, col2 = st.columns(2)
    with col1:
        display_charts(results_df)
    with col2:
        st.markdown("### 📁 Export Results")
        export_data(results_df)

else:
    st.warning("Please enter text data or upload a file to get started.")
