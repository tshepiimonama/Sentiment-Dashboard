import pandas as pd
import requests
from nltk.sentiment.vader import SentimentIntensityAnalyzer
from sklearn.feature_extraction.text import CountVectorizer
import nltk

nltk.download("vader_lexicon")
sid = SentimentIntensityAnalyzer()

API_URL = "https://api-inference.huggingface.co/models/distilbert-base-uncased-finetuned-sst-2-english"
API_KEY = ""  # Replace with your Hugging Face API key
headers = {"Authorization": f"Bearer {API_KEY}"} if API_KEY else {}

def classify_sentiment_vader(compound):
    if compound >= 0.05:
        return "Positive"
    elif compound <= -0.05:
        return "Negative"
    else:
        return "Neutral"

def extract_keywords(texts, top_n=10):
    vec = CountVectorizer(stop_words='english')
    X = vec.fit_transform(texts)
    sum_words = X.sum(axis=0)
    keywords = [(word, sum_words[0, idx]) for word, idx in vec.vocabulary_.items()]
    return sorted(keywords, key=lambda x: x[1], reverse=True)[:top_n]

def analyze_sentiments_vader(text_list):
    rows = []
    for text in text_list:
        score = sid.polarity_scores(text)
        sentiment = classify_sentiment_vader(score['compound'])
        rows.append({
            "Text": text,
            "Sentiment": sentiment,
            "Positive Score": score['pos'],
            "Neutral Score": score['neu'],
            "Negative Score": score['neg'],
            "Confidence": max(score['pos'], score['neu'], score['neg']),
            "Compound Score": score['compound']
        })
    df = pd.DataFrame(rows)
    keywords = extract_keywords(df['Text'].tolist())
    df.attrs['keywords'] = keywords
    return df

def analyze_sentiments_hf(text_list):
    results = []
    for text in text_list:
        if not text.strip():
            continue
        payload = {"inputs": text}
        try:
            response = requests.post(API_URL, headers=headers, json=payload, timeout=10)
            output = response.json()
            if isinstance(output, dict) and output.get("error"):
                label = "Error"
                score = 0
            else:
                label = output[0]['label']
                score = output[0]['score']
            results.append({
                "Text": text,
                "Sentiment": label.capitalize(),
                "Confidence": round(score, 3)
            })
        except Exception:
            results.append({
                "Text": text,
                "Sentiment": "Error",
                "Confidence": 0
            })
    df = pd.DataFrame(results)
    keywords = extract_keywords(df['Text'].tolist())
    df.attrs['keywords'] = keywords
    return df
